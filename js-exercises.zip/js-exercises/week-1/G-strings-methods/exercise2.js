var name = " Ermiyas!  ";
var message= name + "Hello mates";

console.log(message);
