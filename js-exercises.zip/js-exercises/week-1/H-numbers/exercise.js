// Start by creating a variables `numberOfStudents` and `numberOfMentors`
var numberOfStudents=26;
var numberOfMentors=15;
console.log(numberOfStudents+numberOfMentors);
