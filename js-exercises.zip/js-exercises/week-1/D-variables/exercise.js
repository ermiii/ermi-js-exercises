// Start by creating a variable `greeting`

console.log(greeting);
