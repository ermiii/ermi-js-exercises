// Declare your function first
function add (num1,num2){
    return num1 + num2;

}
sum= 13+124;

// Call the function and assign to a variable `sum`

console.log(sum);
