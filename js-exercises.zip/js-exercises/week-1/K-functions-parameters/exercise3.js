// Write your function here
function createGreeting(){
return "Hello! my name is"

   
var greeting = createGreeting + "Daniel";}

console.log(greeting);
