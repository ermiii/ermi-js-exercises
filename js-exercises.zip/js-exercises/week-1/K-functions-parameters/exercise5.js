// Declare your function here
function createLongGreeting(){
    return "my name is";


const greeting = createLongGreeting("Daniel", "i am " + "30");}

console.log(greeting);
