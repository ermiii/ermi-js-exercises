// Complete the function so that it takes input parameters
function multiply(num1,num2) {
  return num1*num2;}
 
 var result = 3*4;
 
 console.log(result);