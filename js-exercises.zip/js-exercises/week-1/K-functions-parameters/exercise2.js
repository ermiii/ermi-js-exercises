// Declare your function first
function divide(num1,num2){
return num1/num2}
var result = divide(3, 4);

console.log(result);
