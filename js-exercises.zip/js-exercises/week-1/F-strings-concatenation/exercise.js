// Start by creating a variable `message`
var message= "Hello Codeyourfuture!!";

console.log(message);
