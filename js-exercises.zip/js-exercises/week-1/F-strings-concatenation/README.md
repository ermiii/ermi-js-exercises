You can add two strings together using the plus operator (`+`):

```js
var greetingStart = "Hello, my name is ";
var name = "Daniel";

var greeting = greetingStart + name;

console.log(greeting); // Logs "Hello, my name is Daniel"
```

## Exercise

* Write a program that logs a message with a greeting and your name

## Expected result

```
Hello, my name is Daniel
```
