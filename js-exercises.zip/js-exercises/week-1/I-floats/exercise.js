var numberOfStudents = 15;
var numberOfMentors = 8;
console.log(15/100, 8/100);
