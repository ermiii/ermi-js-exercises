function halve(number) {
return number /2;
}

var result = halve(12);

console.log(result);
