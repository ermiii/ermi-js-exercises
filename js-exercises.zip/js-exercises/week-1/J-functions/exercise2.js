function triple(number) {
 return number/3;
}

var result = triple(12);

console.log(result);
