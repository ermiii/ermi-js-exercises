// Start by creating a variable `message`

console.log(message);
