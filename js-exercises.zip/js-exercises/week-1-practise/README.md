Like learning a musical instrument, programming requires daily practise.

There are exercises in this folder at 3 different levels with `level-1` being the easiest and `level-3` being the hardest.

Even if you're feeling confident, start at `level-1`. Don't worry about progressing to the more difficult exercises until you feel ready.
