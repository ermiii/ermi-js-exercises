// There is a syntax error with this code. Fix it.

function(a, b, c) {
    return a + b + c;
}

var result = addNumbers(1, 3, 4);
console.log(result); // Expected result 8 - Run the program and make sure it works
