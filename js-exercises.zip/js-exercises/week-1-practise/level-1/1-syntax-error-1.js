// There is a syntax error in this code. Fix it.

function addNumbers(a b c) {
    return a + b + c;
}

var result = addNumbers(1, 3, 4);
console.log(result); // Expected result 8 - Run the program and make sure it works


// Answer these questions:
// 1. How many parameters does the function take?
// 2. What is the function name?
// 3. Where is the function called? with what parameters?