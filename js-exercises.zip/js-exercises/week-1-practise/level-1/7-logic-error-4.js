// The syntax for this function is valid but it has an error, find it and fix it.

function multiply(a, b, c) {
  a * b * c;
  return;
}

var result = multiply(1, 3, 4);
console.log(result);
// Expected result 12
// Run the program and make sure it works
