// The syntax for this function is valid but it has an error, find it and fix it.

function trim(word) {
  return "word".trim();
}

var result = trim("CodeYourFuture  ");
console.log(result);
// Expected result "CodeYourFuture"
// Run the program and make sure it works
