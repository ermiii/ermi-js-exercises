function s(w1, w2) {
    return w1.concat(w2);
}

var result = s('code', 'your');
console.log(result);

// Answer these questions:
// - What does this program do? Run it and see, or Google some of the methods used ot understand them.
// - How many parameters does the function take?
// - What is the function name?
// - Where is the function called? with what parameters?
// - What does the function return?
// - How can this function be improved?