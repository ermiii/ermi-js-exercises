function getNumber() {
    return Math.random() * 10;
}

var result = getNumber();
console.log(result);

// Answer these questions:
// - What does this program do?
// - How many parameters does the function take?
// - What is the function name?
// - Where is the function called? with what parameters?