/*

Describe your own laptop as a JavaScript object

Try to think of as many properties as you can!

*/