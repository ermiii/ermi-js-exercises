/*
    Write code in the space provided so that it outputs "Gilbert"
*/

// WRITE CODE BELOW THIS

// WRITE CODE ABOVE THIS

console.log(kitten.name);

// -> it should output: "Gilbert"