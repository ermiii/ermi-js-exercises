/*
    Write code in the space provided so that the expected values output
*/

var dog = {
    name: 'Billy',
    wantsToPlay: false
};

// WRITE CODE BELOW THIS LINE



// WRITE CODE ABOVE THIS LINE


//DO NOT MODIFY BELOW
console.log(dog.name);
console.log(dog.wantsToPlay);

// it should output:
// Rex
// true