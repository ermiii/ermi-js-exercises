Complete the following CodeWars exercises. Go to the webpages below and follow the instructions there.

Click "ATTEMPT" to test your solution.

Exercises:
- https://www.codewars.com/kata/crash-override/train/javascript
- https://www.codewars.com/kata/strive-matching-number-1/train/javascript
- http://www.codewars.com/kata/strive-matching-number-2/train/javascript
- http://www.codewars.com/kata/strive-matching-number-3/train/javascript