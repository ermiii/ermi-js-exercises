Complete the following CodeWars exercises. Go to the webpages below and follow the instructions there.

Click "ATTEMPT" to test your solution.

Exercises:
- https://www.codewars.com/kata/welcome/train/javascript