// Find the index of an item in an array
// TIP: use the .indexOf() method (search the web for documentation if you're not sure)

var itemToFind = 7;
var arr = [3, 5, 61, 7, 123];
var index; // ONLY EDIT THIS LINE

console.log(index);

/* 
  EXPECTED RESULT
  ---------------
  3
*/
