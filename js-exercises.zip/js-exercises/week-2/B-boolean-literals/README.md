There is a special data type in JavaScript known as a **boolean** value. A boolean is either `true` or `false`, and it should be written without quotes.

```js
var codeYourFutureIsGreat = true;
```

## Exercise

Head over to `exercise.js` and follow the instructions in the comments.
