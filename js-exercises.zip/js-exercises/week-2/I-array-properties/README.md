Arrays, like strings, have a `length` property.

You can check this by starting a node console in your terminal.

```sh
$ node
> var arr = [1, 2, 3];
undefined
> arr
[1, 2, 3]
> arr.length
3
```
